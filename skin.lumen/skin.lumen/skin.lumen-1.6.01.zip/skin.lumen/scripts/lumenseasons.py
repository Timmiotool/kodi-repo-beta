"""Seasons list: focus the season of the episode played most recently (also partly watched), once per opened show."""
import re
import json
import time

import xbmc
import xbmcgui

HOME = xbmcgui.Window(10000)
PROP = "lumen.seasonpath"


def _rpc(method, params):
    request = {"jsonrpc": "2.0", "id": 1, "method": method, "params": params}
    return json.loads(xbmc.executeJSONRPC(json.dumps(request)))


def focus(container_id):
    if xbmc.getCondVisibility("Skin.HasSetting(series.nolast)"):
        return  # option Focus in series: Standard
    path = xbmc.getInfoLabel("Container.FolderPath")
    match = re.match(r"^videodb://tvshows/titles/(\d+)/?(\?.*)?$", path or "")
    if not match:
        return
    # run only once per opened show; going back from the episodes keeps the position Kodi restores
    if HOME.getProperty(PROP) == path:
        return
    result = _rpc("VideoLibrary.GetEpisodes", {"tvshowid": int(match.group(1)),
                                               "properties": ["season", "lastplayed"],
                                               "sort": {"method": "lastplayed", "order": "descending"},
                                               "limits": {"start": 0, "end": 1}})
    episodes = (result.get("result") or {}).get("episodes") or []
    played = [e for e in episodes if e.get("lastplayed") and e.get("season", 0) >= 0]
    HOME.setProperty(PROP, path)
    if not played:
        return
    target = str(played[0]["season"])
    cid = int(container_id)
    count = 0
    for _ in range(30):  # wait until the list is filled
        count = int(xbmc.getInfoLabel("Container.NumItems") or 0)
        if count > 1 and xbmc.getInfoLabel("Container.FolderPath") == path:
            break
        xbmc.sleep(100)
    for index in range(count + 1):  # NumItems does not count the parent ("..") item
        if xbmc.getInfoLabel("Container(%d).ListItemAbsolute(%d).Season" % (cid, index)) == target:
            xbmc.executebuiltin("SetFocus(%d,%d,absolute)" % (cid, index))
            if cid == 59:  # Stream: continue with the episode played last, in the episode list on the right
                _focus_in(63, _episode_matcher(played[0]["episodeid"]))
            return


def focus_episode():
    """Started by the click on a series on the home screen (option home.nooverview off): if Kodi reopens an episode
    list, focus the episode played most recently."""
    if xbmc.getCondVisibility("Skin.HasSetting(series.nolast)"):
        return  # option Focus in series: Standard
    path = ""
    match = None
    for _ in range(60):  # wait until the videos window shows a list (up to 6 s)
        path = xbmc.getInfoLabel("Container.FolderPath")
        if re.match(r"^videodb://tvshows/titles/(\d+)/?(\?.*)?$", path or ""):
            return  # season overview: nothing to do here
        match = re.match(r"^videodb://tvshows/titles/(\d+)/(-?\d+)/", path or "")
        if match and int(xbmc.getInfoLabel("Container.NumItems") or 0) > 1:
            break
        match = None
        xbmc.sleep(100)
    if not match:
        return
    result = _rpc("VideoLibrary.GetEpisodes", {"tvshowid": int(match.group(1)),
                                               "properties": ["season", "lastplayed"],
                                               "sort": {"method": "lastplayed", "order": "descending"},
                                               "limits": {"start": 0, "end": 1}})
    episodes = (result.get("result") or {}).get("episodes") or []
    if not episodes or not episodes[0].get("lastplayed"):
        return
    # season -1 / -2: all seasons in one list (Kodi opens shows with a single season this way)
    if match.group(2) not in ("-1", "-2") and str(episodes[0].get("season")) != match.group(2):
        return
    wanted = str(episodes[0]["episodeid"])
    cid = 0
    for view in (57, 62, 52, 56, 50, 51, 53, 54, 55):
        if xbmc.getCondVisibility("Control.IsVisible(%d)" % view):
            cid = view
            break
    if not cid:
        return
    count = int(xbmc.getInfoLabel("Container.NumItems") or 0)
    for index in range(count + 1):  # NumItems does not count the parent ("..") item
        prefix = "Container(%d).ListItemAbsolute(%d)" % (cid, index)
        if xbmc.getInfoLabel(prefix + ".DBID") == wanted and xbmc.getInfoLabel(prefix + ".DBType") == "episode":
            # the view may still be setting its own start focus: repeat until the episode really is focused
            for _ in range(8):
                xbmc.executebuiltin("SetFocus(%d,%d,absolute)" % (cid, index))
                xbmc.sleep(250)
                if (xbmc.getInfoLabel("Container(%d).ListItem.DBID" % cid) == wanted
                        and xbmc.getCondVisibility("Control.HasFocus(%d)" % cid)):
                    return
            return


def _user_guard():
    """Returns a function that tells whether the user pressed a key since now (the global idle time was reset)."""
    idle0 = xbmc.getGlobalIdleTime()
    t0 = time.time()
    return lambda: xbmc.getGlobalIdleTime() < idle0 + (time.time() - t0) - 1.0


def _focus_in(cid, matcher, tries=45, guard=None):
    """Focus the first item of container `cid` for which matcher(prefix) is true; waits while the list is still filling.
    Stops as soon as the user presses a key, so the automatic focus never fights the remote control."""
    guard = guard or _user_guard()
    for _ in range(tries):
        if guard():
            return False
        count = int(xbmc.getInfoLabel("Container(%d).NumItems" % cid) or 0)
        for index in range(count + 1):  # NumItems does not count the parent ("..") item
            if matcher("Container(%d).ListItemAbsolute(%d)" % (cid, index)):
                xbmc.executebuiltin("SetFocus(%d,%d,absolute)" % (cid, index))
                xbmc.sleep(350)
                # a content list may reload right now (another season): check that the right item is really focused
                if matcher("Container(%d).ListItem" % cid) and xbmc.getCondVisibility("Control.HasFocus(%d)" % cid):
                    return True
                break
        xbmc.sleep(150)
    return False


def _episode_matcher(episode):
    wanted = str(episode)
    return lambda prefix: (xbmc.getInfoLabel(prefix + ".DBID") == wanted
                           and xbmc.getInfoLabel(prefix + ".DBType") == "episode")


def stream_open(dbtype, dbid):
    """Home screen option "Stream" for series: open the Stream season / episode overview directly and jump to the clicked
    episode (episode item) or to the episode played last (show or season item)."""
    try:
        dbid = int(dbid)
    except (TypeError, ValueError):
        return
    show = season = episode = None
    if dbtype == "episode":
        d = (_rpc("VideoLibrary.GetEpisodeDetails", {"episodeid": dbid, "properties": ["tvshowid", "season"]})
             .get("result") or {}).get("episodedetails") or {}
        show, season, episode = d.get("tvshowid"), d.get("season"), dbid
    elif dbtype == "season":
        d = (_rpc("VideoLibrary.GetSeasonDetails", {"seasonid": dbid, "properties": ["tvshowid", "season"]})
             .get("result") or {}).get("seasondetails") or {}
        show, season = d.get("tvshowid"), d.get("season")
    else:
        show = dbid
    if not show:
        return
    if episode is None and not xbmc.getCondVisibility("Skin.HasSetting(series.nolast)"):
        params = {"tvshowid": show, "properties": ["season", "lastplayed"],
                  "sort": {"method": "lastplayed", "order": "descending"}, "limits": {"start": 0, "end": 1}}
        if season is not None:
            params["season"] = season
        played = [e for e in ((_rpc("VideoLibrary.GetEpisodes", params).get("result") or {}).get("episodes") or [])
                  if e.get("lastplayed")]
        if played:
            episode, season = played[0]["episodeid"], played[0].get("season", season)
    guard = _user_guard()
    path = "videodb://tvshows/titles/%d/" % show
    HOME.setProperty(PROP, path)  # the season list must not run its own "focus last played" pass again
    xbmc.executebuiltin('ActivateWindow(Videos,"%s",return)' % path)
    content = ""
    for _ in range(80):  # wait until the videos window shows the show (up to 8 s)
        content = xbmc.getInfoLabel("Container.Content")
        if content in ("seasons", "episodes") and int(xbmc.getInfoLabel("Container.NumItems") or 0) > 0 \
                and xbmc.getInfoLabel("Container.FolderPath").startswith(path):
            break
        content = ""
        xbmc.sleep(100)
    if not content:
        return
    main = 59 if content == "seasons" else 62
    stream_name = xbmc.getLocalizedString(31805)  # view label "Stream"
    for _ in range(15):  # Kodi may apply the view saved for this path after the list is shown: repeat until Stream is active
        if xbmc.getInfoLabel("Container.Viewmode") == stream_name or guard():
            break
        xbmc.executebuiltin("Container.SetViewMode(%d)" % main)
        xbmc.sleep(500)
    if content == "seasons":
        if season is not None:
            _focus_in(59, lambda prefix: xbmc.getInfoLabel(prefix + ".Season") == str(season)
                      and xbmc.getInfoLabel(prefix + ".DBType") == "season", guard=guard)
        if episode:
            _focus_in(63, _episode_matcher(episode), guard=guard)
    elif episode:
        _focus_in(62, _episode_matcher(episode), guard=guard)

def stream_season():
    """Stream season page: Right from the season list puts the focus on the first episode of the highlighted season
    (the episode list on the right holds the episodes of all seasons)."""
    season = xbmc.getInfoLabel("Container(59).ListItem.Season")
    target = 0
    if season not in ("", "-1"):
        count = int(xbmc.getInfoLabel("Container(63).NumItems") or 0)
        for index in range(count + 1):
            if xbmc.getInfoLabel("Container(63).ListItemAbsolute(%d).Season" % index) == season:
                target = index
                break
    xbmc.executebuiltin("SetFocus(63,%d,absolute)" % target)
